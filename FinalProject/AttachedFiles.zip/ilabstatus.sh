cd /root

curl -sS -u 'nagiosadmin:[REDACTED]' http://j-and-b.ilab.cs.uoregon.edu/nagios/cgi-bin//status.cgi?host=all >ilabstatus.txt

sed -i 's/Logged in as / /' ilabstatus.txt
sed -i 's/nagiosadmin/ /' ilabstatus.txt
sed -i 's/90 seconds/2 minutes/' ilabstatus.txt
sed -i 's/View History For all hosts/ /' ilabstatus.txt
sed -i 's/View Notifications For All Hosts/ /' ilabstatus.txt
sed -i 's/View Host Status Detail For All Hosts/ /' ilabstatus.txt
sed -i 's/Service Status Details For All Hosts/Status Details For CIS-399 ilab Hosts/' ilabstatus.txt
sed -i 's,/nagios/stylesheets,stylesheets,g' ilabstatus.txt
sed -i 's,/nagios/images,images,g' ilabstatus.txt
sed -i 's,/nagios/js,js,g' ilabstatus.txt
sed -i 's,Ethan Galstad. -->,Ethan Galstad. --> <META HTTP-EQUIV="refresh" CONTENT="60">,' ilabstatus.txt
sed -i 's/>localhost</>j-and-b</' ilabstatus.txt

cp ilabstatus.txt /var/www/html/ilabstatus/index.html
